KICK KING Android wrapper project

App name: KICK KING
Application ID: com.kickking.game
Version code: 55
Version name: 5.5

WHAT THIS IS
This Android Studio project packages the supplied single-file HTML game inside an Android WebView. JavaScript and DOM storage are enabled so browser-based game logic and localStorage can work.

BUILD AN ANDROID APP BUNDLE (.AAB)
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Open this folder in Android Studio (File > Open).
3. Allow Gradle sync and SDK downloads to finish.
4. Test on an Android device or emulator first.
5. Choose Build > Generate Signed Bundle / APK > Android App Bundle.
6. Create a new upload keystore and keep its password and file private and backed up.
7. Select release, finish the wizard, and locate the generated .aab in app/release/.
8. Upload that .aab to the Google Play Console closed-testing release.

IMPORTANT LIMITATIONS
- This is a starter Android wrapper, not a built or signed .aab file.
- The supplied ZIP contained only index.html and README.txt. The game title inside the HTML is KICK KING V49, while the release-preparation ZIP is labelled V55. Confirm the in-game version before publishing.
- No app icon, privacy policy, data-safety declaration, or store listing assets were supplied.
- Review any online services, permissions, ads, payments, accounts, and data collection before publishing. Do not claim these features work unless tested.
- Test gameplay, sound, screen rotation, offline behavior, back navigation, and saved progress on real devices.
